## The AMQ Broker Base Profile
